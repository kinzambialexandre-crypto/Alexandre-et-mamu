// =========================
// CONFIGURATION
// =========================
// Remplace uniquement la valeur ci-dessous par le numéro WhatsApp d'Alexandre,
// au format international, sans le signe + ni espaces.
// Exemple RDC : "2438XXXXXXXX"
const ALEXANDRE_WHATSAPP = "";

const state = { date: null, place: null };
const screens = [...document.querySelectorAll(".screen")];
const progressBar = document.getElementById("progressBar");

function showScreen(name) {
  screens.forEach(s => s.classList.toggle("active", s.dataset.screen === name));
  const steps = { welcome: 25, question: 33, date: 58, place: 78, final: 100 };
  progressBar.style.width = `${steps[name] || 25}%`;
  window.scrollTo({top: 0, behavior: "smooth"});
}

document.querySelectorAll("[data-next]").forEach(btn => {
  btn.addEventListener("click", () => {
    if (btn.disabled) return;
    showScreen(btn.dataset.next);
  });
});

document.querySelectorAll("[data-date]").forEach(card => {
  card.addEventListener("click", () => {
    document.querySelectorAll("[data-date]").forEach(c => c.classList.remove("selected"));
    card.classList.add("selected");
    state.date = card.dataset.date;
    const next = document.getElementById("dateContinue");
    next.disabled = false;
    next.classList.remove("disabled");
  });
});

document.querySelectorAll("[data-place]").forEach(card => {
  card.addEventListener("click", () => {
    document.querySelectorAll("[data-place]").forEach(c => c.classList.remove("selected"));
    card.classList.add("selected");
    state.place = card.dataset.place;
    const next = document.getElementById("placeContinue");
    next.disabled = false;
    next.classList.remove("disabled");
  });
});

document.getElementById("placeContinue").addEventListener("click", () => {
  if (!state.date || !state.place) return;
  document.getElementById("finalDate").textContent = state.date;
  document.getElementById("finalPlace").textContent = state.place;
  showScreen("final");
  burstHearts(18);
});

document.getElementById("whatsappBtn").addEventListener("click", () => {
  if (!ALEXANDRE_WHATSAPP.trim()) {
    alert("Ajoute d'abord le numéro WhatsApp d'Alexandre dans script.js, dans ALEXANDRE_WHATSAPP.");
    return;
  }
  const message = `Alexandre ❤️ J'ai choisi le ${state.date} pour notre date, et je préfère ${state.place}. 🥰`;
  window.open(`https://wa.me/${ALEXANDRE_WHATSAPP.replace(/\D/g, "")}?text=${encodeURIComponent(message)}`, "_blank");
});

document.getElementById("restartBtn").addEventListener("click", () => {
  state.date = null; state.place = null;
  document.querySelectorAll(".choice").forEach(c => c.classList.remove("selected"));
  document.getElementById("dateContinue").disabled = true;
  document.getElementById("dateContinue").classList.add("disabled");
  document.getElementById("placeContinue").disabled = true;
  document.getElementById("placeContinue").classList.add("disabled");
  showScreen("welcome");
});

function createHeart() {
  const h = document.createElement("span");
  h.className = "float-heart";
  h.textContent = Math.random() > .35 ? "♥" : "♡";
  h.style.left = `${Math.random()*100}%`;
  h.style.fontSize = `${10 + Math.random()*14}px`;
  h.style.animationDuration = `${6 + Math.random()*5}s`;
  document.getElementById("hearts").appendChild(h);
  setTimeout(() => h.remove(), 12000);
}
setInterval(createHeart, 1300);

function burstHearts(count) {
  for (let i=0;i<count;i++) setTimeout(createHeart, i*80);
}
