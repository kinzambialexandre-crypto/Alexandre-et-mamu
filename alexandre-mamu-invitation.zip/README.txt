# Alexandre ❤️ Mamu — Invitation romantique

## Fichiers
- index.html
- style.css
- script.js

## Personnaliser WhatsApp
Dans `script.js`, trouve :
const ALEXANDRE_WHATSAPP = "";

Remplace les guillemets vides par le numéro WhatsApp d'Alexandre au format international, sans `+`, espaces ni tirets.

Exemple :
const ALEXANDRE_WHATSAPP = "2438XXXXXXXX";

## Utilisation locale
Ouvre simplement `index.html` dans Chrome, Safari ou Firefox.

## Mise en ligne gratuite
### Option recommandée : GitHub Pages
1. Crée un compte GitHub.
2. Crée un nouveau dépôt public, par exemple `alexandre-mamu`.
3. Ajoute les trois fichiers à la racine du dépôt.
4. Dans le dépôt : Settings → Pages.
5. Dans “Build and deployment”, choisis “Deploy from a branch”.
6. Choisis la branche `main` et le dossier `/ (root)`.
7. Enregistre. GitHub te donnera une adresse du type :
   `https://TONPSEUDO.github.io/alexandre-mamu/`
8. Copie ce lien et envoie-le à Mamu sur WhatsApp.

Le site ne nécessite ni base de données, ni serveur, ni nom de domaine payant.
